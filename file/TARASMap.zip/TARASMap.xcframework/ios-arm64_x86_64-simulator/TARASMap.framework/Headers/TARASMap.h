//
//  TARASMap.h
//  TARASMap
//
//  Created by nexmond on 2022/04/01.
//

#import <Foundation/Foundation.h>

//! Project version number for TARASMap.
FOUNDATION_EXPORT double TARASMapVersionNumber;

//! Project version string for TARASMap.
FOUNDATION_EXPORT const unsigned char TARASMapVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TARASMap/PublicHeader.h>


